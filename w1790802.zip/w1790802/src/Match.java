import java.io.Serializable;

public class Match implements Serializable {
    int homeTeam;
    int awayTeam;
    int homeGoles;
    int awayGoles;
    Date matchPlayedDate;

    public Match(int homeTeam, int awayTeam, int homeGoles, int awayGoles, Date matchPlayedDate) {
        this.homeTeam = homeTeam;
        this.awayTeam = awayTeam;
        this.homeGoles = homeGoles;
        this.awayGoles = awayGoles;
        this.matchPlayedDate = matchPlayedDate;
    }

    public void setHomeTeam(int homeTeam) {
        this.homeTeam = homeTeam;
    }

    public int getHomeTeam() {
        return homeTeam;
    }

    public void setAwayTeam(int awayTeam) {
        this.awayTeam = awayTeam;
    }

    public int getAwayTeam() {
        return awayTeam;
    }

    public void setHomeGoles(int homeGoles) {
        this.homeGoles = homeGoles;
    }

    public int getHomeGoles() {
        return homeGoles;
    }

    public void setAwayGoles(int awayGoles) {
        this.awayGoles = awayGoles;
    }

    public int getAwayGoles() {
        return awayGoles;
    }

    public Date getMatchPlayedDate() {
        return matchPlayedDate;
    }

    public void setMatchPlayedDate(Date matchPlayedDate) {
        this.matchPlayedDate = matchPlayedDate;
    }
}
