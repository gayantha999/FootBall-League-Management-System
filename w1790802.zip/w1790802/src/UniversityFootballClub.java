public class UniversityFootballClub extends FootballClub {

   // private final int MAX_AGE = 23;


    public UniversityFootballClub(String clubName, int clubID, String clubLocation, int howManyMembers, int sesonesWin, int sesonesLoss, int sesonesDrow, int receivedGoles, int scoredGoels, int points, int numberOfMathesPlayed) {
        super(clubName, clubID, clubLocation, howManyMembers, sesonesWin, sesonesLoss, sesonesDrow, receivedGoles, scoredGoels, points, numberOfMathesPlayed);
    }

    public UniversityFootballClub(String clubName, int clubID, int clubMembers, String clubLocation) {
        super(clubName, clubID, clubMembers, clubLocation);
    }
}
