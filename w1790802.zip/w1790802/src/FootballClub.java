import java.io.Serializable;

public class FootballClub extends SportsClub implements Serializable ,Comparable {
    int howManyMembers = 0;
    int sesonesWin = 0;
    int sesonesLoss = 0;
    int sesonesDrow = 0;
    int receivedGoles = 0;
    int scoredGoels = 0;
    int points = 0;
    int numberOfMathesPlayed = 0;

    public FootballClub(String clubName, int clubID, String clubLocation, int howManyMembers, int sesonesWin, int sesonesLoss, int sesonesDrow, int receivedGoles, int scoredGoels, int points, int numberOfMathesPlayed) {
        super(clubName, clubID, clubLocation);
        this.howManyMembers = howManyMembers;
        this.sesonesWin = sesonesWin;
        this.sesonesLoss = sesonesLoss;
        this.sesonesDrow = sesonesDrow;
        this.receivedGoles = receivedGoles;
        this.scoredGoels = scoredGoels;
        this.points = points;
        this.numberOfMathesPlayed = numberOfMathesPlayed;
    }

    public FootballClub(String month, int day, int year, String homeClubID) {
    }


    public int getHowManyMembers() {
        return howManyMembers;
    }

    public void setHowManyMembers(int howManyMembers) {
        this.howManyMembers = howManyMembers;
    }


    public int getSesonesWin() {
        return sesonesWin;
    }

    public void setSesonesWin(int sesonesWin) {
        this.sesonesWin = sesonesWin;
    }


    public int getSesonesLoss() {
        return sesonesLoss;
    }

    public void setSesonesLoss(int sesonesLoss) {
        this.sesonesLoss = sesonesLoss;
    }


    public int getSesonesDrow() {
        return sesonesDrow;
    }

    public void setSesonesDrow(int sesonesDrow) {
        this.sesonesDrow = sesonesDrow;
    }


    public int getScoredGoels() {
        return scoredGoels;
    }

    public void setScoredGoels(int scoredGoels) {
        this.scoredGoels = scoredGoels;
    }


    public int getReceivedGoles() {
        return receivedGoles;
    }

    public void setReceivedGoles(int receivedGoles) {
        this.receivedGoles = receivedGoles;
    }


    public void setPoints(int points) {
        this.points = points;
    }

    public int getPoints() {
        return points;
    }


    public void setNumberOfMathesPlayed(int numberOfMathesPlayed) {
        this.numberOfMathesPlayed = numberOfMathesPlayed;
    }

    public int getNumberOfMathesPlayed() {
        return numberOfMathesPlayed;
    }

    @Override
    public String toString() {
        return "FootballClub{" +
                "howManyMembers=" + howManyMembers +
                ", sesonesWin=" + sesonesWin +
                ", sesonesLoss=" + sesonesLoss +
                ", sesonesDrow=" + sesonesDrow +
                ", receivedGoles=" + receivedGoles +
                ", scoredGoels=" + scoredGoels +
                ", points=" + points +
                ", numberOfMathesPlayed=" + numberOfMathesPlayed +
                ", clubName='" + clubName + '\'' +
                ", location='" + location + '\'' +
                ", clubID=" + clubID +
                '}';
    }

    @Override
    public int compareTo(Object o) {
        int comparePoints = ((FootballClub) o).getPoints();
        return comparePoints - this.points;
    }

}


