import javafx.scene.control.TextField;

import java.io.Serializable;

public class Date extends TextField implements Serializable  {
    int day;
    int mont;
    int year;

    public Date(int day, int mont, int year) {
        this.day = day;
        this.mont = mont;
        this.year = year;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMont() {
        return mont;
    }

    public void setMont(int mont) {
        this.mont = mont;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
