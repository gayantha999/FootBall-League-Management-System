import java.io.Serializable;

public class SportsClub implements Serializable {
     String clubName;
     String location;
     int clubID;

    //default constructor
    SportsClub() {

    }

    SportsClub(String clubName, int clubID, String clubLocation) {
        setClubID(clubID);
        setClubName(clubName);
        setLocation(clubLocation);
    }

    //setter and getters for variables
    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }


    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getClubID() {
        return clubID;
    }

    public void setClubID(int clubID) {
        this.clubID = clubID;
    }



}
