import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;

public class PremierLeagueManager implements LeagueManager {

    public static ArrayList<FootballClub> footballClubArrayList = new ArrayList<>();

    public PremierLeagueManager() {

    }

    public static void setFootballClubArrayList(ArrayList<FootballClub> footballClubArrayList) {
        PremierLeagueManager.footballClubArrayList = footballClubArrayList;
    }

    public static ArrayList<FootballClub> getFootballClubArrayList() {
        return footballClubArrayList;
    }

    public static ArrayList<Match> PlayedMatchArrayList = new ArrayList<>();


    @Override
    public void deleteClub(int deleteClubID) {

    }

    @Override
    public void registerClub() {

    }

    @Override
    public void createFootballClub(int clubType, String clubName, int clubID, int clubMembers, String clubLocation, String month, int day, int year, String homeClubID) {
        if (clubType == 1) {
            FootballClub footballClubObject = new SchoolFootballClub(month, day, year, homeClubID);
            footballClubArrayList.add(footballClubObject);
        } else if (clubType == 2) {
            FootballClub footballClubObject = new UniversityFootballClub(clubName, clubID, clubMembers, clubLocation);
            footballClubArrayList.add(footballClubObject);
        }
        System.out.println(footballClubArrayList.size());

    }

    @Override
    public void addplayedMatch(int homeClubID, int awayclubID, int day, int month, int year, int homeGoals, int awayGoals) {
        FootballClub homeClub = FindFootballClub(homeClubID);
        FootballClub awayClub = FindFootballClub(awayclubID);

        Date date = new Date(day, month, year);
        Match match = new Match(homeClubID, awayclubID, homeGoals, awayGoals, date);

        PlayedMatchArrayList.add(match);

        homeClub.setNumberOfMathesPlayed(homeClub.getNumberOfMathesPlayed() + 1);
        awayClub.setNumberOfMathesPlayed(awayClub.getNumberOfMathesPlayed() + 1);

        homeClub.setScoredGoels(homeGoals);
        awayClub.setScoredGoels(awayGoals);
        homeClub.setReceivedGoles(awayGoals);
        awayClub.setReceivedGoles(homeGoals);


        if (homeGoals > awayGoals) {
            homeClub.setSesonesWin(homeClub.getSesonesWin() + 1);
            awayClub.setSesonesLoss(awayClub.getSesonesLoss() + 1);
            homeClub.setPoints(homeClub.getPoints() + 2);
        } else if (homeGoals < awayGoals) {
            awayClub.setSesonesWin(awayClub.getSesonesWin() + 1);
            homeClub.setSesonesLoss(homeClub.getSesonesLoss() + 1);
            awayClub.setPoints(awayClub.getPoints() + 2);
        } else {
            awayClub.setSesonesDrow(awayClub.getSesonesDrow() + 1);
            homeClub.setSesonesDrow(homeClub.getSesonesDrow() + 1);
            homeClub.setPoints(homeClub.getPoints() + 1);
            awayClub.setPoints(awayClub.getPoints() + 1);
        }
    }

    @Override
    public void save() {
        try {
            FileOutputStream fileOutputStreamClub = new FileOutputStream("output.ser");
            ObjectOutputStream objectOutputStreamClub = new ObjectOutputStream(fileOutputStreamClub);
            objectOutputStreamClub.writeObject(footballClubArrayList);
            objectOutputStreamClub.flush();
            objectOutputStreamClub.close();
            System.out.println("-----saved-----");
            FileOutputStream fileOutputStream = new FileOutputStream("match.ser");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(PlayedMatchArrayList);
            objectOutputStream.flush();
            objectOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void load() {
        try {
            FileInputStream readData = new FileInputStream("output.ser");
            ObjectInputStream readStream = new ObjectInputStream(readData);
            footballClubArrayList = (ArrayList<FootballClub>) readStream.readObject();
            readStream.close();

            FileInputStream readData2 = new FileInputStream("match.ser");
            ObjectInputStream readStream2 = new ObjectInputStream(readData2);
            PlayedMatchArrayList = (ArrayList<Match>) readStream2.readObject();
            readStream2.close();
        } catch (FileNotFoundException e) {


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static FootballClub FindFootballClub(int clubID) {
        for (FootballClub footballClub : footballClubArrayList) {
            if (footballClub.getClubID() == clubID) {

                return footballClub;
            }
        }

        return null;
    }
static void randomMatch(){
    ArrayList<Integer>finalList=RandomFootballCLub();
    finalList.get(0);
    finalList.get(1);
    Random random=new Random();
   int randomG1=random.nextInt(50);
   int randomG2=random.nextInt(50);
   try {


       Date matchDate = new Date(27, 12, 2020);
       Match matchObject = new Match(0, 1, randomG1, randomG2, matchDate);
       PremierLeagueManager randomadd=new PremierLeagueManager();
       randomadd.addplayedMatch(0, 1, matchDate.getDay(), matchDate.getMont(), matchDate.getYear(), randomG1, randomG2);

       PlayedMatchArrayList.addAll((Collection<? extends Match>) matchObject);

       System.out.println(matchObject);
   }catch (NullPointerException e){
       System.out.println("not related club");
   }
}
public static ArrayList<Integer> RandomFootballCLub(){
    ArrayList<Integer>list =new ArrayList<Integer>();
    for (FootballClub football:footballClubArrayList){
        list.add(football.getClubID());
    }
        int random1=0;
        int random2=0;
        Collections.shuffle(list);
        random1=list.get(0);
        Collections.shuffle(list);
        random2=list.get(1);


    ArrayList<Integer>arrayList=new ArrayList<Integer>();
    arrayList.add(random1);
    arrayList.add(random2);
        return arrayList;
    }


}






