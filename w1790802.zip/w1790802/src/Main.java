import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
public class Main extends Application {
    LeagueManager premierLeagueManager = new PremierLeagueManager() {

    };


    public static void main(String args[]) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        premierLeagueManager.load();

        Scanner scanner = new Scanner(System.in);

        while (true) {

            System.out.println("        -Premier League Tournament-");

            System.out.println("------------------------------------------");
            System.out.println("|               MENU SELECTION           |");
            System.out.println("------------------------------------------");
            System.out.println("| Options:                               |");
            System.out.println("|        1. Add a  Football Club         |");
            System.out.println("|        2. Delete a Football Club       |");
            System.out.println("|        3. Display Statistics of a club |");
            System.out.println("|        4. Display Points Table         |");
            System.out.println("|        5. Add a Played Match           |");
            System.out.println("|        6. Save                         |");
            System.out.println("|        7. Print Played Match by date   |");
            System.out.println("|        8. Show GUI                     |");
            System.out.println("|       0. Exit                          |");

            System.out.println("------------------------------------------");
            Integer option = Integer.parseInt(scanner.next());
            switch (option) {
                case 1:
                    registerClub();
                    break;
                case 2:
                    deleteClub();
                    break;
                case 3:
                    printClubDetails();
                    break;
                case 4:
                    displayPointsTable();
                    break;
                case 5:
                    addPlayedMatch();
                    break;
                case 6:
                    save();
                    break;
                case 7:
                    printPlayedMatches();
                    break;
                case 8:
                    showGui();
                    break;
                case 0:
                    exit();
                    break;

            }
        }
    }

    private void showGui() throws FileNotFoundException {
        Stage stage = new Stage();
        stage.setTitle("PremierLeague Manager");
        Button firstButton = new Button("Point Table");
        Font fontFir = Font.font("Verdana", FontWeight.BOLD, 16);
        firstButton.setLayoutX(200);
        firstButton.setLayoutY(300);
        firstButton.setMaxSize(90, 80);
        firstButton.setMinSize(170, 80);
        firstButton.setPrefSize(90, 80);
        firstButton.setFont(fontFir);
        firstButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                GUIPointTable();
            }
        });

        Button exitButton = new Button("Exit");
        Font font = Font.font("Courier New", FontWeight.EXTRA_BOLD, 26);
        exitButton.setLayoutX(350);
        exitButton.setLayoutY(600);
        exitButton.setMaxSize(100, 80);
        exitButton.setMinSize(100, 80);
        exitButton.setPrefSize(100, 80);
        exitButton.setFont(font);


        exitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                exit();
            }
        });
        Button PlyedMatchButton = new Button("Search BY Date");
        Font fontSer = Font.font("Verdana", FontWeight.BOLD, 16);
        PlyedMatchButton.setLayoutX(400);
        PlyedMatchButton.setLayoutY(300);
        PlyedMatchButton.setMaxSize(90, 80);
        PlyedMatchButton.setMinSize(170, 50);
        PlyedMatchButton.setPrefSize(90, 80);
        PlyedMatchButton.setFont(fontSer);
        PlyedMatchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //SearchBYDate();
                printPlayedMatches();
            }
        });
        AnchorPane pane = new AnchorPane();
        pane.getChildren().addAll(firstButton, exitButton, PlyedMatchButton);
        Scene scene = new Scene(pane, 800, 800);



        stage.setScene(scene);
        stage.showAndWait();
    }


    private void GUIPointTable() {
        Stage stageOne = new Stage();
        stageOne.setTitle("Point Table");

        TableView<FootballClub> tableViewPoint;
        TableColumn<FootballClub, String> nameColoum = new TableColumn<>("Club Name");
        nameColoum.setMinWidth(200);
        nameColoum.setCellValueFactory(new PropertyValueFactory<>("clubName"));

        TableColumn<FootballClub, Integer> IDColoum = new TableColumn<>("Club ID");
        IDColoum.setMinWidth(100);
        IDColoum.setCellValueFactory(new PropertyValueFactory<>("clubID"));

        TableColumn<FootballClub, Integer> LocationColoum = new TableColumn<>("Club Location");
        LocationColoum.setMinWidth(200);
        LocationColoum.setCellValueFactory(new PropertyValueFactory<>("location"));

        TableColumn<FootballClub, Integer> membersnColoum = new TableColumn<>("Club Members");
        membersnColoum.setMinWidth(100);
        membersnColoum.setCellValueFactory(new PropertyValueFactory<>("howManyMembers"));

        TableColumn<FootballClub, Integer> wonColoum = new TableColumn<>("WON");
        wonColoum.setMinWidth(100);
        wonColoum.setCellValueFactory(new PropertyValueFactory<>("sesonesWin"));
        TableColumn<FootballClub, Integer> lostColoum = new TableColumn<>("LOST");
        lostColoum.setMinWidth(100);
        lostColoum.setCellValueFactory(new PropertyValueFactory<>("sesonesLoss"));

        TableColumn<FootballClub, Integer> drowColoum = new TableColumn<>("DRAW");
        drowColoum.setMinWidth(100);
        drowColoum.setCellValueFactory(new PropertyValueFactory<>("sesonesDrow"));

        TableColumn<FootballClub, Integer> recevidColoum = new TableColumn<>("Received goals");
        recevidColoum.setMinWidth(100);
        recevidColoum.setCellValueFactory(new PropertyValueFactory<>("receivedGoles"));

        TableColumn<FootballClub, Integer> scordColoum = new TableColumn<>("Scored goals");
        scordColoum.setMinWidth(100);
        scordColoum.setCellValueFactory(new PropertyValueFactory<>("scoredGoels"));
        TableColumn<FootballClub, Integer> pointColoum = new TableColumn<>("POINT");
        pointColoum.setMinWidth(100);
        pointColoum.setCellValueFactory(new PropertyValueFactory<>("points"));

        TableColumn<FootballClub, Integer> matchColoum = new TableColumn<>("Matches");
        matchColoum.setMinWidth(100);
        matchColoum.setCellValueFactory(new PropertyValueFactory<>("numberOfMathesPlayed"));


        tableViewPoint = new TableView<>();
        tableViewPoint.setItems(getData());
        tableViewPoint.getColumns().addAll(nameColoum, IDColoum, LocationColoum, membersnColoum, wonColoum, lostColoum, drowColoum, recevidColoum, scordColoum, pointColoum, matchColoum);

        pointColoum.setSortType(TableColumn.SortType.DESCENDING);
        tableViewPoint.getSortOrder().add(pointColoum);
        tableViewPoint.sort();

        VBox vBox = new VBox();
        vBox.getChildren().addAll(tableViewPoint);


                wonColoum.setSortType(TableColumn.SortType.DESCENDING);
                tableViewPoint.getSortOrder().add(wonColoum);
                tableViewPoint.sort();



                matchColoum.setSortType(TableColumn.SortType.DESCENDING);
                tableViewPoint.getSortOrder().add(matchColoum);
                tableViewPoint.sort();



        Button randomButton = new Button("Random");
        Font fontRandom = Font.font("Courier New", FontWeight.EXTRA_BOLD, 26);
        randomButton.setLayoutX(320);
        randomButton.setLayoutY(500);
        randomButton.setMaxSize(90, 80);
        randomButton.setMinSize(170, 80);
        randomButton.setPrefSize(90, 80);
        randomButton.setFont(fontRandom);
        randomButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                PremierLeagueManager.randomMatch();
                tableViewPoint.refresh();
            }
        });


        Button HomePoint = new Button("HOME");
        Font font = Font.font("Courier New", FontWeight.EXTRA_BOLD, 26);
        HomePoint.setLayoutX(790);
        HomePoint.setLayoutY(500);
        HomePoint.setMaxSize(100, 85);
        HomePoint.setMinSize(100, 80);
        HomePoint.setPrefSize(100, 80);
        HomePoint.setFont(font);
        HomePoint.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    showGui();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });


        AnchorPane panePoint = new AnchorPane();
        stageOne.setScene(new Scene(panePoint, 1300, 800));
        panePoint.getChildren().addAll(vBox, randomButton, HomePoint);
        stageOne.showAndWait();
    }

    public ObservableList<FootballClub> getData() {
        ObservableList<FootballClub> data = FXCollections.observableArrayList();
        for (FootballClub footballClub : PremierLeagueManager.footballClubArrayList
        ) {
            data.addAll(footballClub);
        }
        return data;
    }

    private void exit() {
        System.out.println("-----Exited-----");
        System.exit(0);
    }

    private void save() {
        premierLeagueManager.save();
    }

    private long printPlayedMatches() {
        Scanner playedMatch = new Scanner(System.in);
        System.out.println("Match played Date:-");
        int day = playedMatch.nextInt();
        System.out.println("Match played Month:-");
        int month = playedMatch.nextInt();
        System.out.println("Match played Year:-");
        int year = playedMatch.nextInt();


        int count = 0;
        ArrayList<Match> MatchDetailsArrayList = new ArrayList<>();
        for (Match match : PremierLeagueManager.PlayedMatchArrayList) {
            if ((match.getMatchPlayedDate().getDay() == day) && (match.getMatchPlayedDate().getMont() == month) && (match.getMatchPlayedDate().getYear() == year)) {
                MatchDetailsArrayList.add(match);
                count++;
            }
        }
        if (count == 0) {
            System.out.println("No Played Match in this date");

        } else if (count > 0) {
            PrintMatchDetails(MatchDetailsArrayList, count);
        }
        return 0;
    }

    public void PrintMatchDetails(ArrayList<Match> matchArrayList, int count) {

        System.out.println("This date had " + count + " Matches");
        System.out.println();
        for (Match match : matchArrayList) {
            System.out.println("Home Team ID : " + match.getHomeTeam());
            System.out.println("Home Goals : " + match.getHomeGoles());
            System.out.println("Away Team : " + match.getAwayTeam());
            System.out.println("Away Goal : " + match.getAwayGoles());
            System.out.println();
        }

    }

    private void addPlayedMatch() {
        Scanner matchDetails = new Scanner(System.in);
        System.out.println("Please enter Match Details");
        System.out.println("Match Played Day:- ");
        int day = matchDetails.nextInt();
        System.out.println("Match Played Month:- ");
        int month = matchDetails.nextInt();
        System.out.println("Match Played Year:- ");
        int year = matchDetails.nextInt();
        System.out.println("Home Club ID:- ");
        int homeClubID = matchDetails.nextInt();
        System.out.println("Away Club ID:- ");
        int awayclubID = matchDetails.nextInt();
        System.out.println("Number of Home Goals:- ");
        int homeGoals = matchDetails.nextInt();
        System.out.println("Number of Away Goals:- ");
        int awayGoals = matchDetails.nextInt();

        premierLeagueManager.addplayedMatch(homeClubID, awayclubID, day, month, year, homeGoals, awayGoals);
    }


    private void displayPointsTable() {
        System.out.println("-----------------------------------------------------------------------------");
        System.out.printf("%5s %10s %10s %10s %10s %10s ", "CLUB ID", "CLUB NAME", "MATCHES", "WON", "LOST", "POINTS  ");
        System.out.println();
        System.out.println("-----------------------------------------------------------------------------");
        Collections.sort(PremierLeagueManager.footballClubArrayList);
        for (FootballClub footballClub : PremierLeagueManager.footballClubArrayList) {
            System.out.format("%5s %10s %10s %10s %10s %10s",
                    footballClub.getClubID(), footballClub.getClubName(), footballClub.getNumberOfMathesPlayed(),
                    footballClub.getSesonesWin(), footballClub.getSesonesLoss(), footballClub.getPoints());
            System.out.println();
        }
        System.out.println("-----------------------------------------------------------------------------");
    }

    private void printClubDetails() {
        Scanner scannerClubID = new Scanner(System.in);
        System.out.println("Club ID:- ");
        int clubID = scannerClubID.nextInt();
        FootballClub footballClub = PremierLeagueManager.FindFootballClub(clubID);
        System.out.println("--------------------------CLUB DETAILS --------------------------------");

        System.out.println("Club ID  : " + footballClub.getClubID());
        System.out.println("Club Name  : " + footballClub.getClubName());
        System.out.println("Location  : " + footballClub.getLocation());
        System.out.println("Player count  : " + footballClub.getHowManyMembers());
        System.out.println("Matches Played  : " + footballClub.getNumberOfMathesPlayed());
        System.out.println("Wins  : " + footballClub.getSesonesWin());
        System.out.println("Losses  : " + footballClub.getSesonesLoss());
        System.out.println("Draws : " + footballClub.getSesonesDrow());
        System.out.println("Points : " + footballClub.getPoints());
        System.out.println("Goals Scored : " + footballClub.getScoredGoels());
        System.out.println();
        System.out.println("----------------------------------------------------------------------");


    }

    private void deleteClub() {
        Scanner scannerClubID = new Scanner(System.in);
        System.out.println("Club ID:- ");
        int deleteClubID = scannerClubID.nextInt();
        FootballClub footballClub = PremierLeagueManager.FindFootballClub(deleteClubID);
        PremierLeagueManager.footballClubArrayList.remove(footballClub);
        System.out.println("-----Club Deleted-----");
        premierLeagueManager.deleteClub(deleteClubID);

    }

    private void registerClub() {
        Scanner registerScanner = new Scanner(System.in);
        System.out.println("Enter Football Club Type (1 - School Football Club/ 2 - University Football Club)");
        Integer option = Integer.parseInt(registerScanner.next());
        switch (option) {
            case 1:
                createFootballClub(1);
                break;
            case 2:
                createFootballClub(2);
                break;
            default:
                System.out.println("Invalid Input");
                premierLeagueManager.registerClub();

        }
    }

    private static void createFootballClub(int clubType) {
        int win = 0;
        int lost = 0;
        int draw = 0;
        int recivedGoael = 0;
        int scordGoeal = 0;
        int point = 0;
        int numberofMatches = 0;

        Scanner clubDetails = new Scanner(System.in);
        System.out.println("Please enter Club Details");
        System.out.println("Club name:- ");
        String clubName = clubDetails.nextLine();
        System.out.println("Club ID:- ");
        int clubID = clubDetails.nextInt();
        System.out.println("Number of players:- ");
        int clubMembers = clubDetails.nextInt();
        System.out.println("Club Location:- ");
        String clubLocation = clubDetails.next();
        FootballClub footballClub = new FootballClub(clubName, clubID, clubLocation, clubMembers, win, lost, draw, recivedGoael, scordGoeal, point, numberofMatches);
        PremierLeagueManager.footballClubArrayList.add(footballClub);

        System.out.println("........Your Club Is Registered........");


    }



}