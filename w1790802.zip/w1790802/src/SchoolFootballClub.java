public class SchoolFootballClub extends FootballClub  {
    private final int MAX_AGE = 18;

    public SchoolFootballClub(String clubName, int clubID, String clubLocation, int howManyMembers, int sesonesWin, int sesonesLoss, int sesonesDrow, int receivedGoles, int scoredGoels, int points, int numberOfMathesPlayed) {
        super(clubName, clubID, clubLocation, howManyMembers, sesonesWin, sesonesLoss, sesonesDrow, receivedGoles, scoredGoels, points, numberOfMathesPlayed);
    }

    public SchoolFootballClub(String month, int day, int year, String homeClubID) {
        super(month, day, year, homeClubID);
    }

    /*public SchoolFootballClub(String clubName, int clubID, int clubMembers, String clubLocation){
        super(clubName, clubID, clubMembers, clubLocation);
    }*/
}
