public interface LeagueManager {
    void deleteClub(int deleteClubID);
    void registerClub();
    void createFootballClub(int clubType, String clubName, int clubID, int clubMembers, String clubLocation, String month, int day, int year, String homeClubID);
    void addplayedMatch(int homeClubID, int awayclubID, int day, int month, int year, int homeGoals, int awayGoals);
    void save();
    void load();


}
